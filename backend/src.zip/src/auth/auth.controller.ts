import { Body, Controller, Post, UnauthorizedException } from '@nestjs/common';
import { AuthService } from './auth.service';
import { UsersService } from 'src/users/users.service';
import * as bcrypt from 'bcrypt';

@Controller('auth')
export class AuthController {
  constructor(
    private readonly authService: AuthService,
    private readonly userService: UsersService,
  ) {}

  @Post('login')
  async login(@Body() body: { email: string; password: string }) {
    return this.authService.login(body.email, body.password);
  }

  @Post('register')
  async register(
    @Body() body: {
      name: string; email: string; password: string; role?: string 
}
  ) {
    const existing = await this.userService.findByEmail(body.email);
    if (existing) {
      throw new UnauthorizedException('User already exists');
    }

    const hashedPassword = await bcrypt.hash(body.password, 10);

    const user = await this.userService.create({
      name:body.name,
      email: body.email,
      password: hashedPassword,
      role: body.role || 'student', // default role: student
    });

    return {
      message: 'User registered successfully',
      user: {
        id: user._id,
        name:user.name,
        email: user.email,
        role: user.role,
      },
    };
  }
}
