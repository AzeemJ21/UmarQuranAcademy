// import {
//   Controller,
//   Get,
//   Query,
//   Put,
//   Delete,
//   Param,
//   Body,
// } from '@nestjs/common';
// import { UsersService } from './users.service';

// @Controller('user')
// export class UsersController {
//   constructor(private readonly userService: UsersService) {}

//   // ✅ Get all users (optionally filtered by role)
//   @Get()
//   async getAllUsers(@Query('role') role?: string) {
//     return this.userService.findAll(role);
//   }

//   @Put(':id')
//   async updateUser(@Param('id') id: string, @Body() body) {
//     return this.userService.update(id, body);
//   }

//   @Delete(':id')
//   async deleteUser(@Param('id') id: string) {
//     return this.userService.delete(id);
//   }

//   // ✅ Assign students to a teacher
//   @Put('assign-students/:teacherId')
//   async assignStudentsToTeacher(
//     @Param('teacherId') teacherId: string,
//     @Body('studentIds') studentIds: string[],
//   ) {
//     return this.userService.assignStudentsToTeacher(teacherId, studentIds);
//   }

//   // ✅ Get assigned students of a teacher
//   @Get('students/:teacherId')
//   async getStudentsOfTeacher(@Param('teacherId') teacherId: string) {
//     return this.userService.getStudentsOfTeacher(teacherId);
//   }
// }
